ExpenseTree.java
class ExpenseTree {
    private class TreeNode {
        Expense expense;
        TreeNode left, right;

        TreeNode(Expense expense) {
            this.expense = expense;
            left = right = null;
        }
    }

    private TreeNode root;

    public void add(Expense expense) {
        root = addRecursive(root, expense);
    }

    private TreeNode addRecursive(TreeNode node, Expense expense) {
        if (node == null) {
            return new TreeNode(expense);
        }

        if (expense.getAmount() < node.expense.getAmount()) {
            node.left = addRecursive(node.left, expense);
        } else if (expense.getAmount() > node.expense.getAmount()) {
            node.right = addRecursive(node.right, expense);
        }

        return node;
    }

    public void view() {
        System.out.println("Expenses (Tree):");
        inOrderTraversal(root);
    }

    private void inOrderTraversal(TreeNode node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.println(node.expense);
            inOrderTraversal(node.right);
        }
    }
}