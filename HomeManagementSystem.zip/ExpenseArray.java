ExpenseArray.java
class ExpenseArray {
    private Expense[] expenses;
    private int size;

    public ExpenseArray(int capacity) {
        expenses = new Expense[capacity];
        size = 0;
    }

    public void add(Expense expense) {
        if (size < expenses.length) {
            expenses[size++] = expense;
        } else {
            System.out.println("Expense array is full.");
        }
    }

    public void view() {
        System.out.println("Expenses (Array):");
        for (int i = 0; i < size; i++) {
            System.out.println(expenses[i]);
        }
    }
}