Expensequeue.java
import java.util.LinkedList;
import java.util.Queue;

class ExpenseQueue {
    private Queue<Expense> expenses = new LinkedList<>();

    public void enqueue(Expense expense) {
        expenses.add(expense);
    }

    public void view() {
        System.out.println("Expenses (Queue):");
        for (Expense expense : expenses) {
            System.out.println(expense);
        }
    }
}