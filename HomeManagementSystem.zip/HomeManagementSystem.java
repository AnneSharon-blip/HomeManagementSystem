HomeManagementSystem.java 
import java.util.Scanner;

public class HomeManagementSystem {
    public static void main(String[] args) {
        HomeManagementSystem hms = new HomeManagementSystem();
        hms.run();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        ExpenseStack expenseStack = new ExpenseStack();
        ExpenseQueue expenseQueue = new ExpenseQueue();
        ExpenseArray expenseArray = new ExpenseArray(100); // Array size of 100
        ExpenseList expenseList = new ExpenseList();
        ExpenseTree expenseTree = new ExpenseTree();

        while (true) {
            System.out.println("\nHome Management System - Expense Tracking:");
            System.out.println("1. Add Expense");
            System.out.println("2. View Expenses (Stack)");
            System.out.println("3. View Expenses (Queue)");
            System.out.println("4. View Expenses (Array)");
            System.out.println("5. View Expenses (List)");
            System.out.println("6. View Expenses (Tree)");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter expense description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter expense amount: ");
                    double amount = scanner.nextDouble();
                    Expense expense = new Expense(description, amount);

                    expenseStack.push(expense);
                    expenseQueue.enqueue(expense);
                    expenseArray.add(expense);
                    expenseList.add(expense);
                    expenseTree.add(expense);

                    System.out.println("Expense added.");
                    break;
                case 2:
                    expenseStack.view();
                    break;
                case 3:
                    expenseQueue.view();
                    break;
                case 4:
                    expenseArray.view();
                    break;
                case 5:
                    expenseList.view();
                    break;
                case 6:
                    expenseTree.view();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}