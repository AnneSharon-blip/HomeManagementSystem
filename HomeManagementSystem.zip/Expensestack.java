Expensestack.java
import java.util.Stack;

class ExpenseStack {
    private Stack<Expense> expenses = new Stack<>();

    public void push(Expense expense) {
        expenses.push(expense);
    }

    public void view() {
        System.out.println("Expenses (Stack):");
        for (Expense expense : expenses) {
            System.out.println(expense);
        }
    }
}